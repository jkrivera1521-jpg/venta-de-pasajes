package com.ventapasajes.template.api;

import java.time.Instant;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(name = "ServiceStatus", description = "Basic service status response.")
public record ServiceStatus(
        @Schema(example = "ok") String status,
        @Schema(example = "quarkus-service-template") String service,
        @Schema(example = "quarkus") String runtime,
        Instant checkedAt) {

    public static ServiceStatus ok(String service) {
        return new ServiceStatus("ok", service, "quarkus", Instant.now());
    }
}
