# Quarkus Service Template

Plantilla base para microservicios backend Quarkus del sistema Venta de Pasajes.

## Incluye

- Quarkus `3.25.2` con Java 21.
- REST con `quarkus-rest-jackson`.
- Hibernate ORM Panache y PostgreSQL JDBC.
- Flyway para migraciones.
- SmallRye OpenAPI y Swagger UI.
- SmallRye Health.
- Logs JSON configurables por entorno.
- Pruebas base con `@QuarkusTest` y REST Assured.

## Endpoints base

```text
GET /api/v1/template/health
GET /q/health
GET /q/health/live
GET /q/health/ready
GET /q/openapi
GET /q/swagger-ui
```

## Ejecutar pruebas

```powershell
mvn -f .\services\quarkus-service-template\pom.xml test
```

## Crear un servicio desde la plantilla

Ejemplo para `identity-service`:

```powershell
.\scripts\new-quarkus-service.ps1 `
  -ServiceName identity-service `
  -PackageSegment identity `
  -DatabaseName identity_db `
  -HttpPort 8081
```

Luego:

```powershell
mvn -f .\services\identity-service\pom.xml test
```

## Secretos

La plantilla no guarda secretos reales. Los servicios generados deben leer Secret Manager usando referencias como:

```text
<service>__db-connection
identity-service__jwt-signing-secret
```

Las variables sensibles nunca deben quedar en `.env`, `application.properties` ni archivos de notas.
